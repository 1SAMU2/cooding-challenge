# OpenAI Frontend Application

This is an Angular application that consumes the OpenAI Text Processing API.

## Setup Instructions

1. Clone the repository.
2. Navigate to the project folder.
3. Install dependencies:
   ```bash
   npm install