import os
from typing import Dict

import openai
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

# Ensure you have set your OpenAI key in your environment variables
openai.api_key = os.getenv("OPENAI_API_KEY")

app = FastAPI(title="OpenAI Text Processing API")

class TextInput(BaseModel):
    text: str

class ProcessedResponse(BaseModel):
    response: str

@app.post("/process", response_model=ProcessedResponse)
async def process_text(input_data: TextInput):
    try:
        # Customize the prompt and model as needed
        prompt = f"Process the following text and provide a response based on the model's training:\n\n{input_data.text}"
        completion = openai.Completion.create(
            engine="text-davinci-003",
            prompt=prompt,
            max_tokens=150,
            temperature=0.7
        )
        generated_text = completion.choices[0].text.strip()
        return ProcessedResponse(response=generated_text)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)